#include "pawn.h"

Pawn::Pawn(PieceType pt, Colour colour, int value) : Piece(pt, colour,value) {}

