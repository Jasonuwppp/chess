#include "knight.h"

Knight::Knight(PieceType pt, Colour colour, int value) : Piece(pt, colour,value) {}

