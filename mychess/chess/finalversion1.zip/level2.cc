#include "level2.h"
using namespace std;

Level2::Level2(PlayerType type, string name, Colour colour): Computer(type, name, colour) {}


