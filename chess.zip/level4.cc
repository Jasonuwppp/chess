#include "level4.h"
using namespace std;

Level4::Level4(PlayerType type, string name, Colour colour): Computer(type, name, colour) {}

