#ifndef _KNIGHT_H_
#define _KNGIHT_H_

#include "piece.h"

class Knight : public Piece {
public:
    Knight(PieceType pt, Colour colour, int value);
};

#endif

