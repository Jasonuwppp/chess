#include "computer.h"
using namespace std;

Computer::Computer(PlayerType type, string name, Colour colour): Player(type, name, colour) {}
