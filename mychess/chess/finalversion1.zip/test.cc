#include <iostream>
using namespace std;

int main() {
    cout << "Jacob" << endl;
    cout << "Jason" << endl;
}
